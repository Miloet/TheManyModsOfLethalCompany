# Blåhaj
Replaces Plastic Fish with a Blåhaj! 
(this is a reupload of ReplaceFishtoyWithBlahaj but with a better name)
