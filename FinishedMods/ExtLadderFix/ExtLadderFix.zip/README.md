# ExtensionLadderFix

Makes the extension ladder easier to place and assures it will not clip and fall through the map, making you lose it and the $60 you spent on it.

## Contact
If you find any bugs or have any ideas for changes, message me on Discord: @miloet or create a thread on the [GitHub](https://github.com/Miloet/TheManyModsOfLethalCompany/issues) page.