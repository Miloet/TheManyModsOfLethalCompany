# Raccoon Plush

Adds a new adorable furry little friend to find! Squeezing it has been scientifically proven to reduce stress and improve workplace morale!

## Settings
- Rarity on each moon
- Weight
- Value range

## Pictures
![Raccoon Plush](https://i.imgur.com/B7l8Un2.png)
![How did they get up there?](https://i.imgur.com/Fwfk7Vi.png)
![Romantic](https://i.imgur.com/EL3WZN5.png)
![Second favorite spot](https://i.imgur.com/IeiXXX5.png)
![Favorite spot](https://i.imgur.com/FMtvTUN.png)

## Contact
If you find any bugs or have any ideas for changes, message me on Discord: @miloet or create a thread on the GitHub page.

Model made by Melody (Discord/Twitter: @Sweetstarfish84)