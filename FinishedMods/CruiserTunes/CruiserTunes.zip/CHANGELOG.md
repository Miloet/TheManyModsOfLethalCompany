## Patch notes
- **1.2.1** 
	- Bug fixes

- **1.2.0** 
	- Removed console debug message
	- Added setting for removing the random quality / interference

- **1.1.2** 
	- Updated README.md with more detailed instructions of how to add custom songs and create custom song mods

- **1.1.1** 
	- Updated README.md

- **1.1.0**
	- Added additional compatability with modpacks
	- The .mp3 files can now be in any folder within the 'BepInEx\plugins' directory

- **1.0.1**
	- Corrected dependencies

- **1.0.0**
	- Release