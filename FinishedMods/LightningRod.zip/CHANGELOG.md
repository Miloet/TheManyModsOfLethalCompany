## Patch notes

- **1.0.1**
	- Added correct dependencies

- **1.0.0**
	- Release