# Lighning Rod

Adds a new ship upgrade, the Lightning Rod! When turned on it will redirect lightning to the ship as well as keep track of how much it has been doing. Hope your navigator has good eyesight in the dark!

## Settings
- Price
- Chance to avert random lightning
- Chance to avert targeted lightning

## Contact
If you find any bugs or have any ideas for changes, message me on Discord: @miloet or create a thread on the GitHub page.