# Sandwich
Adds a new scrap item to the world- and one you can eat and enjoy will all your friends at that!

## Settings
(Note: The config files are entirely local. If your group wants a restriction on certain items then you all need to have the same config file)

- Rarity on each moon
- Healing
- Sandwich size
- Speed of consumption

## Example pictures:
(https://imgur.com/5WBgCqL)
(https://imgur.com/FZTbHHX)

## Contact
If you find any bugs or have any ideas for changes message me on discord: @miloet or create a thread on the github page