## Patch notes

- **1.0.1**
	- Made value change when eating correct (was bugged)
	- Fixed visual desync issue
	- Added setting for healing the critical-injury status

- **1.0.0**
	- Release