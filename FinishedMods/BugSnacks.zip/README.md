# Happy Hoarders

Adds a new equipment item that can be given to the hoarding bugs to make them friendly for a period of time! They are a great way to outsource scrap collecting or simply make friends!

Oh, and I should mention they found this thing called "The Constitution of the United States," and they REALLY like the second part, so they will sometimes ~~steal shotguns from nutcrackers~~ find shotguns!

## Settings

(Note: The config files are entirely local. If your group wants a restriction on certain items, then you all need to have the same config file)

- Price
- How many bugs should always show up
- Chance to spawn with a shotgun

## Contact

If you find any bugs or have any ideas for changes, message me on Discord: @miloet or create a thread on the GitHub page.
